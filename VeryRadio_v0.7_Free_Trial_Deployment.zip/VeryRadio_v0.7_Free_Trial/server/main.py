"""Very Radio prototype signaling and provisional points server. NOT production payout infrastructure."""
import asyncio, json, os, secrets, sqlite3, time
from collections import defaultdict
from datetime import datetime, timezone
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse

app=FastAPI(title='Very Radio prototype')
DB=os.getenv('VERY_DB','very.db')
rooms={}; clients={}; likes_cooldown={}; lock=asyncio.Lock()

def connect_db():
    db=sqlite3.connect(DB)
    db.execute('CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, host TEXT, title TEXT, started REAL, ended REAL, seconds INTEGER DEFAULT 0, likes INTEGER DEFAULT 0)')
    db.execute('CREATE TABLE IF NOT EXISTS likes (session_id TEXT, viewer TEXT, created REAL)')
    db.commit();return db

def calc_points(seconds,likes):
    return (seconds//1800)*40+(80 if seconds>=14400 else 0)+likes//2

def snapshot():
    return [{'id':sid,'title':r['title'],'host':r['host'],'listeners':sum(1 for p in r['peers'].values() if p['role']=='listener')} for sid,r in rooms.items()]

async def send(ws,payload):
    await ws.send_json(payload)

async def broadcast(room,payload,exclude=None):
    for uid,p in list(room['peers'].items()):
        if uid!=exclude:
            try: await send(p['ws'],payload)
            except Exception: pass

@app.get('/health')
def health(): return {'status':'ok','mode':'prototype','payout_enabled':False}

@app.get('/rooms')
def list_rooms():return snapshot()

@app.websocket('/ws')
async def socket(ws:WebSocket):
    await ws.accept(); uid=secrets.token_hex(8); joined=None
    await send(ws,{'type':'welcome','id':uid,'warning':'Demo points cannot be redeemed'})
    try:
        while True:
            m=await ws.receive_json(); typ=m.get('type')
            if typ=='list':await send(ws,{'type':'rooms','rooms':snapshot()})
            elif typ=='create':
                if joined:continue
                title=str(m.get('title','Veryラジオ'))[:70]
                sid=secrets.token_hex(5)
                rooms[sid]={'host':uid,'title':title,'started':time.time(),'likes':0,'peers':{uid:{'ws':ws,'role':'host'}},'last_activity':time.time()}
                joined=sid
                with connect_db() as db:db.execute('INSERT INTO sessions(id,host,title,started) VALUES (?,?,?,?)',(sid,uid,title,time.time()))
                await send(ws,{'type':'created','room':sid});
            elif typ=='join':
                sid=str(m.get('room',''))
                if joined or sid not in rooms:await send(ws,{'type':'error','message':'ルームが見つかりません'});continue
                r=rooms[sid];r['peers'][uid]={'ws':ws,'role':'listener'};joined=sid
                await send(ws,{'type':'joined','room':sid,'host':r['host']})
                await broadcast(r,{'type':'peer-joined','peer':uid},uid)
            elif typ in ('offer','answer','ice') and joined in rooms:
                target=str(m.get('to',''));p=rooms[joined]['peers'].get(target)
                if p:await send(p['ws'],{'type':typ,'from':uid,'data':m.get('data')})
            elif typ=='comment' and joined in rooms:
                body=str(m.get('text','')).strip()[:250]
                if body:await broadcast(rooms[joined],{'type':'comment','from':uid[:6],'text':body})
            elif typ=='like' and joined in rooms:
                r=rooms[joined]
                if uid==r['host']:continue
                now=time.monotonic(); key=(joined,uid)
                if now-likes_cooldown.get(key,0)<10:continue
                likes_cooldown[key]=now;r['likes']+=1
                await broadcast(r,{'type':'likes','count':r['likes'],'provisional_like_points':r['likes']//2})
            elif typ=='stats' and joined in rooms:
                r=rooms[joined];duration=int(time.time()-r['started']);await send(ws,{'type':'stats','seconds':duration,'likes':r['likes'],'provisional_points':calc_points(duration,r['likes']),'redeemable_points':0})
    except (WebSocketDisconnect,RuntimeError,ValueError):pass
    finally:
        if joined in rooms:
            r=rooms[joined];r['peers'].pop(uid,None)
            if uid==r['host']:
                duration=int(time.time()-r['started']);
                with connect_db() as db:db.execute('UPDATE sessions SET ended=?,seconds=?,likes=? WHERE id=?',(time.time(),duration,r['likes'],joined))
                await broadcast(r,{'type':'ended'});rooms.pop(joined,None)
            else:await broadcast(r,{'type':'peer-left','peer':uid})
